# cbSitemap

This module generate sitemap when pages/entries are created or deleted.

This will generate sitemap_pages.xml and sitemap_entries.xml